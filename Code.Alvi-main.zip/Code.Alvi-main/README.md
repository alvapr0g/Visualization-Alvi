# Webinar Youtube


Introducción práctica a la visualización de datos D3JS



## Curso completo
[AQUÍ](https://www.youtube.com/watch?v=NWovCp-7JTo&t=3s&ab_channel=GarajedeIdeas)
